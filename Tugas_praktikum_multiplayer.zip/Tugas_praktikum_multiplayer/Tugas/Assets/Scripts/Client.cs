﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System;
using UnityEngine;

public class Client : MonoBehaviour {

    public TcpClient tcpClient;
    public StreamWriter sWriter;
    public static Client Instance;
    public string messageReceived;
    bool OnReceiving = false;
    public float x_obj;
    public float y_obj;
    bool eExist = false;

    // Use this for initialization
    void Start()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(this);
        }
    }

    public void ConnectToHost (string hostAdress)
    {
        tcpClient = new TcpClient(hostAdress, 4444);
        Debug.Log("Connected To Server");
        Debug.Log(" ");

        Thread thread = new Thread(Read);
        thread.Start(tcpClient);
        sWriter = new StreamWriter(tcpClient.GetStream());
    }
    private void Update()
    {
        if (OnReceiving)
        {
            string[] theData = messageReceived.Split('|');
            x_obj = float.Parse(theData[0]);
            y_obj = float.Parse(theData[1]);
            if(eExist == false)
            {
                GameManager.Instance.spawnEnemy(x_obj, y_obj);
                eExist = true;
            }
            
        }
        else
        {

        }
     
    }

    //test
    void sendData()
    {
        try
        {
            while (true)
            {
                if (tcpClient.Connected)
                {
                    sWriter.WriteLine("message from client");
                    sWriter.Flush();
                }
            }
        }
        catch(Exception e)
        {
            Debug.Log(e.Message);
        }
        
    }

    void Read(object obj)
    {
        TcpClient tcpClient = (TcpClient)obj;
        StreamReader sReader = new StreamReader(tcpClient.GetStream());

        while (true)
        {
            try
            {
                // receive data
                messageReceived = sReader.ReadLine();
                //Debug.Log(messageReceived);
                OnReceiving = true;
            }
            catch (Exception e)
            {
                Debug.Log(e.Message);
                break;
            }
        }
    }
    public void CloseClientSocket()
    {
        try
        {
            tcpClient.Close();
            Debug.Log("Socket Closed");
        }
        catch(Exception e)
        {
            Debug.Log(e.Message);
        }
        
    }

}
	
	
