﻿using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour {
    
    public static GameManager Instance { get; set; }
    public static bool isOver;
    public GameObject opponent;
    // Use this for initialization
    void Start () {
        if (Instance == null)
        {
            Instance = this;
        }
        isOver = false;
	}
	
	// Update is called once per frame
	void Update () {
        //Debug.Log(Client.Instance.x_obj + " , " + Client.Instance.y_obj);
       
    }

   public void GameOver() {
        if(isOver == false)
        {
            Debug.Log("Game Over");
            isOver = true;
            //Client.Instance.CloseClientSocket();
            SceneManager.LoadScene(0);
        }
    }

    public void spawnEnemy(float i, float j)
    {
        Instantiate(opponent, new Vector2(i,j), Quaternion.identity);
    }

  
}
