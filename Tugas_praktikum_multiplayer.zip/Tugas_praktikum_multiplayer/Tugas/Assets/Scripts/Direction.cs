﻿using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Direction : MonoBehaviour {

    public static Direction Instance { get; set; }

	// Use this for initialization
	void Start () {
        if (Instance == null)
        {
            Instance = this;
        }
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void ConnectToServer(string IP)
    {
        IP = GameObject.Find("HostAdress").GetComponent<InputField>().text;
        if (IP == "")
            IP = "127.0.0.1";
        Client.Instance.ConnectToHost(IP);
        SceneManager.LoadScene(1);
    }
}
