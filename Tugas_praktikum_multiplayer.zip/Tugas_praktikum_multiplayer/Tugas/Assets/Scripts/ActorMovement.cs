﻿using System.Collections;
using UnityEngine;

public class ActorMovement : MonoBehaviour {

    public float speed;
    private Rigidbody2D rb2d;
    public GameObject finalDestination;

	// Use this for initialization
	void Start () {
        rb2d = GetComponent<Rigidbody2D>();
        finalDestination = GameObject.Find("FinishPoint");
        Physics2D.IgnoreCollision(finalDestination.gameObject.GetComponent<CircleCollider2D>(), this.gameObject.GetComponent<CircleCollider2D>());
    }
	
	// Update is called once per frame
	void FixedUpdate () {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");
        Vector2 movement = new Vector2(moveHorizontal, moveVertical);

        rb2d.AddForce(movement * speed);
        sentPosition(this.gameObject.transform.position.x, this.gameObject.transform.position.y);
        DetectPosition();
        
	}

    void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.collider.tag == "obstacle")
        {
            Debug.Log("Hit the Offset");
            rb2d.AddForce(new Vector2(-transform.position.x, -transform.position.y) * 10f);
        }
    }

    void DetectPosition()
    {
        Vector2 pos = new Vector2(this.gameObject.transform.position.x, this.gameObject.transform.position.y);
        RaycastHit2D hit = Physics2D.Raycast(pos, Vector2.zero);
        if(hit.collider != null)
        {
            if(hit.collider.name == ("FinishPoint"))
            {

                //Debug.Log("overlap with "+" "+hit.collider.name);
                FindObjectOfType<GameManager>().GameOver();
                Destroy(this.gameObject);
            }
        }
    }

    void sentPosition(float x, float y)
    {
        string xCoord = x.ToString();
        string yCoord = y.ToString();
        Client.Instance.sWriter.WriteLine(xCoord + "|" + yCoord);
        Client.Instance.sWriter.Flush();
    }
}
