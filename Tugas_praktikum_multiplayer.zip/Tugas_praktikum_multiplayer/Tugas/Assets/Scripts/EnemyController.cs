﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyController : MonoBehaviour {

    public Rigidbody2D rbody;
	// Use this for initialization
	void Start () {
        rbody = GetComponent<Rigidbody2D>();
    }
	
	// Update is called once per frame
	void FixedUpdate () {
        float x = Client.Instance.x_obj;
        float y = Client.Instance.y_obj;
        transform.position = new Vector2(x, y);
    }
}
